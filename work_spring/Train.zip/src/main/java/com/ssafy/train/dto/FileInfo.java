package com.ssafy.train.dto;

import lombok.Data;

@Data
public class FileInfo {
	private String number;
	private String originFile;
	private String saveFile;
	private String saveFolder;
}
