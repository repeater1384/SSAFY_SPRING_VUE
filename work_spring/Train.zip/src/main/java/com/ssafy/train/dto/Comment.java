package com.ssafy.train.dto;

import lombok.Data;

@Data
public class Comment {
	private int comment_id;
	private String content;
	private String id;
}
